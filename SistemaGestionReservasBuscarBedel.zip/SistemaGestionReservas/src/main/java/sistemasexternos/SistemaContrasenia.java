
package sistemasexternos;

public class SistemaContrasenia {
    
    public static PoliticasContrasenia politicasContrasenia = new PoliticasContrasenia(8, true, true, true);
  
}
