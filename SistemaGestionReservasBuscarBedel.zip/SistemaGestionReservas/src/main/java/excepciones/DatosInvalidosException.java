
package excepciones;

public class DatosInvalidosException extends Exception {
    
    public DatosInvalidosException(){
        super("Datos inválidos.");
    }
}
